import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpParams } from "@angular/common/http";
import { NgForm } from '@angular/forms';
import { GridOptions } from "ag-grid-community";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor (private httpClient:HttpClient){ 
  }
  rowData=[];
  requests = [];
  listTeamNames = [];
  teamNameList = [];
  podLeadList=[];
  buHeadList=[];
  private ratio=0.0;
  private effortForSP=0.0;
  private reqChangesPer=0.0;
  private devTeamNotDevPer=0.0;
  private designChangesPer=0.0;
  private prodIssuesPer=0.0;
  private defectsPer=0.0;
  
  @ViewChild('sprintDetails') sprintDetailsForm: NgForm;

  ngOnInit() {
      //this.setDefaultValues();
      this.getTeamsList();
      this.getBuHeadList();
      this.getPodLeadList();
      this.getSprintData();
  }

    calculatePercent(){
    // console.log("HI1",this.sprintDetailsForm.value.completed);
    // console.log("HI2",this.sprintDetailsForm.value.commited);
    var ratioPer= Number(((this.sprintDetailsForm.value.completed/this.sprintDetailsForm.value.commited)*100).toFixed(2));
    var efforForSpPer= Number((this.sprintDetailsForm.value.capacityValue/this.sprintDetailsForm.value.completed).toFixed(2));
    var reqChangesPerTemp= Number( ((this.sprintDetailsForm.value.requirementChanges/this.sprintDetailsForm.value.capacityValue)*100).toFixed(2));
    var devTeamNotDevPerTemp= Number(((this.sprintDetailsForm.value.devTeamNotDeveloping/this.sprintDetailsForm.value.capacityValue)*100).toFixed(2));
    var designChangesPerTemp=Number(((this.sprintDetailsForm.value.designChanges/this.sprintDetailsForm.value.capacityValue)*100).toFixed(2));
    var prodIssuesPerTemp=Number(((this.sprintDetailsForm.value.prodIssues/this.sprintDetailsForm.value.capacityValue)*100).toFixed(2));
    var defectsPerTemp=Number(((this.sprintDetailsForm.value.defectsRework/this.sprintDetailsForm.value.capacityValue)*100).toFixed(2));
    this.ratio= (isNaN(ratioPer))?0.00:ratioPer;
    this.effortForSP= (isNaN(efforForSpPer))?0.00:efforForSpPer;
    this.reqChangesPer= (isNaN(reqChangesPerTemp))?0.00:reqChangesPerTemp;
    this.devTeamNotDevPer= (isNaN(devTeamNotDevPerTemp))?0.00:devTeamNotDevPerTemp;
    this.designChangesPer= (isNaN(designChangesPerTemp))?0.00:designChangesPerTemp;
    this.prodIssuesPer= (isNaN(prodIssuesPerTemp))?0.00:prodIssuesPerTemp;
    this.defectsPer= (isNaN(defectsPerTemp))?0.00:defectsPerTemp;
  }

  // calculateEffortForSp(){
  //   var efforForSpPer= (this.sprintDetailsForm.value.capacity/this.sprintDetailsForm.value.completed);
  //   this.effortForSP= (isNaN(efforForSpPer))?0.00:efforForSpPer;
  // }

  getTeamDataForGrid(event)
  {
    if((event.target.teamNameSelect.value).length>0)
    {
      this.httpClient.get('http://localhost:3000/dashboard/getsprintdata/team',{ params: new HttpParams().set('teamName',event.target.teamNameSelect.value) })
      .subscribe(
          (data:any) => {
            console.log(data);
            this.rowData=data;
            //this.rowData=Array.of(data);
            //console.log(this.rowData);
          }
        )
    }
    else if((event.target.podLeadSelect.value).length>0)
    {
      this.httpClient.get('http://localhost:3000/dashboard/getsprintdata/pod',{ params: new HttpParams().set('podLead',event.podLeadSelect.value) })
      .subscribe(
          (data:any) => {
            console.log(data);
            this.rowData=data;
            //this.rowData=Array.of(data);
            //console.log(this.rowData);
          }
        )
    }
    else if((event.target.buHeadSelect.value).length>0)
    {
      this.httpClient.get('http://localhost:3000/dashboard/getsprintdata/bu',{ params: new HttpParams().set('buHead',event.podLeadSelect.buHeadSelect.value) })
      .subscribe(
          (data:any) => {
            console.log(data);
            this.rowData=data;
            //this.rowData=Array.of(data);
            //console.log(this.rowData);
          }
        )
    }
    // console.log("Hi1",event.target.buHeadSelect.value);
    // console.log("Hi2",event.target.podLeadSelect.value);
    // console.log("Hi3",event.target.teamNameSelect.value);
  }

//   setDefaultValues()
//   {
//     this.sprintDetailsForm.reset();
//     console.log("setdefault values")
//     this.sprintDetailsForm.form.patchValue({
//       ratio:this.ratio,
//       effortForSP:this.effortForSP,
//       reqChangesPer:this.defaultReqChangesPer,
//       devTeamNotDevPer:this.defaultDevTeamNotDevPer,
//       designChangesPer:this.defaultDesignChangesPer,
//       prodIssuesPer:this.defaultProdIssuesPer
//     });

//     console.log(this.sprintDetailsForm.value.ratio);
//  }

  setPodLeadList(event)
  {
    this.httpClient.get('http://localhost:3000/dashboard/getPodLeadBasedOnBuHead',{ params: new HttpParams().set('buHead',event.target.value) })
    .subscribe(
        (data:any) => {
          console.log(data);
          this.podLeadList=data;
          //this.rowData=Array.of(data);
          //console.log(this.rowData);
        }
      )
      this.httpClient.get('http://localhost:3000/dashboard/getTeamListBasedOnBuHead',{ params: new HttpParams().set('buHead',event.target.value) })
      .subscribe(
          (data:any) => {
            console.log(data);
            this.teamNameList=data;
            //this.rowData=Array.of(data);
            //console.log(this.rowData);
          }
        )
  }

  setTeamList(event)
  {
    this.httpClient.get('http://localhost:3000/dashboard/getTeamListBasedOnPodLead',{ params: new HttpParams().set('podLead',event.target.value) })
    .subscribe(
        (data:any) => {
          console.log(data);
          this.teamNameList=data;
          //this.rowData=Array.of(data);
          //console.log(this.rowData);
        }
      )
  }

  registerTeam(event){
    console.log("event triggered");
    event.preventDefault()
    const target = event.target;
    const teamName= target.querySelector('#teamName').value;
    const devLead= target.querySelector('#devLead').value;
    const podLead= target.querySelector('#podLead').value;
    const buhead= target.querySelector('#buhead').value;
    console.log(teamName, devLead);
    //this.getData(teamName)
    //this.postData(teamName, devLead, podLead, buhead);
  }


  getTeamDetails(event){
    event.preventDefault()
    const target = event.target;
    const teamName= target.querySelector('#teamNameGet').value;
    this.getData(teamName);
  }

  getTeamsList()
  {
    console.log("entered teams list");
    this.httpClient.get('http://localhost:3000/dashboard/getteamDetails')
    .subscribe(
        (data:any) => {
          console.log(data);
          this.listTeamNames=data;
          this.teamNameList=data;
          console.log(this.listTeamNames[0].teamName);
        }
      )
  }

  getBuHeadList()
  {
    console.log("entered teams list");
    this.httpClient.get('http://localhost:3000/dashboard/getbudata')
    .subscribe(
        (data:any) => {
          console.log(data);
          //this.listTeamNames=data;
          this.buHeadList=data;
          console.log(this.listTeamNames[0].teamName);
        }
      )
  }

  getPodLeadList()
  {
    console.log("entered teams list");
    this.httpClient.get('http://localhost:3000/dashboard/getpodLeaddata')
    .subscribe(
        (data:any) => {
          console.log(data);
          //this.listTeamNames=data;
          this.podLeadList=data;
          console.log(this.listTeamNames[0].teamName);
        }
      )
  }

  addSprintDetails(event){
    this.httpClient.post('http://localhost:3000/dashboard/postsprintdata', {})
.subscribe(
  (data:any[]) => {
    console.log(data);
  }
)
  }
  
 getData(teamName){
    this.httpClient.get('http://localhost:3000/dashboard/getteamdata',{ params: new HttpParams().set('teamName',teamName) })
      .subscribe(
          (data:any) => {
            console.log(data);
            this.rowData=data;
            //this.rowData=Array.of(data);
            //console.log(this.rowData);
          }
        )
  }

  getSprintData(){
    this.httpClient.get('http://localhost:3000/dashboard/getSprintData')
      .subscribe(
          (data:any) => {
            console.log(data);
            this.rowData=data;
            //this.rowData=Array.of(data);
            //console.log(this.rowData);
          }
        )
  }

  postData(event){ 
    var teamName= event.target.teamNameEnter.value;
    var sprintName=event.target.sprintNameEnter.value;
    var sprintStartDate=event.target.startDate.value;
    var sprintEndDate=event.target.endDate.value
    var capacity=event.target.capacityValue.value;
    var storyCommited=event.target.commited.value;
    var storyCompleted=event.target.completed.value;
    var perCompletion=event.target.ratio.value;
    var storiesReady=event.target.readyForSprint.value;
    var defectsLowerPlatform=event.target.nOfDefectInAlfaDelta.value;
    var defectsHigherPlatform= event.target.nOfDefectInBetaAndAbove.value;
    var effortPerSp=event.target.effortForSP.value;
    var wasteReqChanges=event.target.requirementChanges.value;
    var wasteDevTeamNotDeveloping=event.target.devTeamNotDeveloping.value;
    var wasteDesignChanges=event.target.designChanges.value;
    var wasteProdIssues=event.target.prodIssues.value;
    var wasteReworkDefects= event.target.defectsRework.value;
    var perWasteReqChanges= event.target.reqChangesPer.value;
    var perWasteDevTeamNotDeveloping=event.target.devTeamNotDevPer.value;
    var perWasteDesignChanges=event.target.designChangesPer.value;
    var perWasteProdIssues=event.target.prodIssuesPer.value;
    var perDefectRework=event.target.defectsPer.value;
    var insprintNoOfScen=event.target.noOfTestScen.value;
    var insprintRegression=event.target.regScenarios.value;
    var insprintAutomated=event.target.automatedScenarios.value;
    var comments=event.target.comment.value;
    this.httpClient.post('http://localhost:3000/dashboard/postsprintdata', {
      teamName
,capacity
,storyCommited
,storyCompleted
,storiesReady
,defectsLowerPlatform
,defectsHigherPlatform
,wasteReqChanges
,wasteDevTeamNotDeveloping
,wasteDesignChanges
,wasteProdIssues
,wasteReworkDefects
,insprintNoOfScen
,insprintRegression
,insprintAutomated
,sprintName
,sprintStartDate
,sprintEndDate
,perCompletion
,effortPerSp
,perWasteReqChanges
,perWasteDevTeamNotDeveloping
,perWasteDesignChanges
,perWasteProdIssues
,perDefectRework
,comments
})
      .subscribe(
          (data:any[]) => {
            console.log(data);
          }
        )
  }
  columnDefs = [
    {
      headerName: "teamName",
      field: "teamName"
    },
    {
      headerName: "sprintName",
      field: "sprintName"
    },
    {
      headerName: "sprintStartDate",
      field: "sprintStartDate"
    },
    {
      headerName: "sprintEndDate",
      field: "sprintEndDate"
    },
    {
      headerName: "capacity",
      field: "capacity"
    },
    {
      headerName: "storyCommited",
      field: "storyCommited"
    },
    {
      headerName: "storyCompleted",
      field: "storyCompleted"
    },
    {
      headerName: "perCompletion",
      field: "perCompletion"
    },
    {
      headerName: "storiesReady",
      field: "storiesReady"
    },
    {
      headerName: "defectsLowerPlatform",
      field: "defectsLowerPlatform"
    },
    {
      headerName: "defectsHigherPlatform",
      field: "TdefectsHigherPlatform"
    },
    {
      headerName: "effortPerSp",
      field: "effortPerSp"
    },
    {
      headerName: "wasteReqChanges",
      field: "wasteReqChanges"
    },
    {
      headerName: "wasteDevTeamNotDeveloping",
      field: "wasteDevTeamNotDeveloping"
    },
    {
      headerName: "wasteDesignChanges",
      field: "wasteDesignChanges"
    },
    {
      headerName: "wasteProdIssues",
      field: "wasteProdIssues"
    },
    {
      headerName: "wasteReworkDefects",
      field: "wasteReworkDefects"
    },
    {
      headerName: "perWasteReqChanges",
      field: "perWasteReqChanges"
    },
    {
      headerName: "perWasteDevTeamNotDeveloping",
      field: "perWasteDevTeamNotDeveloping"
    },
    {
      headerName: "perWasteDesignChanges",
      field: "perWasteDesignChanges"
    },
    {
      headerName: "perWasteProdIssues",
      field: "TperWasteProdIssues"
    },
    {
      headerName: "perDefectRework",
      field: "perDefectRework"
    },
    {
      headerName: "insprintNoOfScen",
      field: "insprintNoOfScen"
    },
    {
      headerName: "insprintRegression",
      field: "insprintRegression"
    },
    {
      headerName: "insprintAutomated",
      field: "DinsprintAutomated"
    },
    {
      headerName: "comments",
      field: "comments"
    }
  ];
}